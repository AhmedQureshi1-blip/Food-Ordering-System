<?php
if(isset($_POST['add_to_cart'])){
    // Sanitize and validate inputs
    $pid = filter_var($_POST['pid'], FILTER_VALIDATE_INT);
    $name = htmlspecialchars(strip_tags($_POST['name']));
    $price = filter_var($_POST['price'], FILTER_VALIDATE_FLOAT);
    $image = htmlspecialchars(strip_tags($_POST['image']));
    $qty = filter_var($_POST['qty'], FILTER_VALIDATE_INT);

    // Validate inputs
    if($pid === false || $pid <= 0){
        $cart_messages[] = 'Invalid product ID!';
    }elseif($name === ''){
        $cart_messages[] = 'Invalid product name!';
    }elseif($price === false || $price <= 0){
        $cart_messages[] = 'Invalid price!';
    }elseif($image === ''){
        $cart_messages[] = 'Invalid image!';
    }elseif($qty === false || $qty <= 0 || $qty > 99){
        $cart_messages[] = 'Invalid quantity!';
    }else{
        // Check if item already exists in cart
        $check_cart = $conn->prepare("SELECT * FROM `cart` WHERE user_id = ? AND pid = ?");
        $check_cart->execute([$user_id, $pid]);

        if($check_cart->rowCount() > 0){
            $cart_messages[] = 'Item already in cart!';
        }else{
            // Add to cart
            $insert_cart = $conn->prepare("INSERT INTO `cart`(user_id, pid, name, price, quantity, image) VALUES(?,?,?,?,?,?)");
            $insert_cart->execute([$user_id, $pid, $name, $price, $qty, $image]);
            $cart_messages[] = 'Added to cart!';
        }
    }
}
?>