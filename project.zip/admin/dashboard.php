<?php
include '../components/connect.php';
session_start();

$admin_id = $_SESSION['admin_id'];

if(!isset($admin_id)){
   header('location:admin_login.php');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Dashboard</title>
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
   <link rel="stylesheet" href="../css/admin_style.css">
</head>
<body>
<?php include '../components/admin_header.php' ?>

<section class="dashboard">
   <h1 class="heading">Dashboard</h1>

   <!-- Debugging: Display orders table contents -->
   <?php
   $debug_orders = $conn->prepare("SELECT id, user_id, total_price, payment_status FROM `orders`");
   $debug_orders->execute();
   echo '<div style="margin-bottom: 20px;">';
   echo '<h3>Debug: Orders Table</h3>';
   if($debug_orders->rowCount() > 0){
      echo '<table border="1" style="border-collapse: collapse; width: 100%; max-width: 600px;">';
      echo '<tr><th>ID</th><th>User ID</th><th>Total Price</th><th>Payment Status</th></tr>';
      while($row = $debug_orders->fetch(PDO::FETCH_ASSOC)){
         echo '<tr>';
         echo '<td>' . htmlspecialchars($row['id']) . '</td>';
         echo '<td>' . htmlspecialchars($row['user_id']) . '</td>';
         echo '<td>' . htmlspecialchars($row['total_price']) . '</td>';
         echo '<td>' . htmlspecialchars($row['payment_status'] ?: 'NULL') . '</td>';
         echo '</tr>';
      }
      echo '</table>';
   }else{
      echo '<p>No orders found in the database.</p>';
   }
   echo '</div>';
   ?>

   <div class="box-container">
      <div class="box">
         <h3>Welcome Admin!</h3>
         <p><?= htmlspecialchars($fetch_profile['name']); ?></p>
         <a href="update_profile.php" class="btn">Update Profile</a>
      </div>

      <div class="box">
         <?php
         $total_pendings = 0;
         $select_pendings = $conn->prepare("SELECT total_price FROM `orders` WHERE payment_status = ?");
         $select_pendings->execute(['pending']);
         while($fetch_pendings = $select_pendings->fetch(PDO::FETCH_ASSOC)){
            $total_pendings += $fetch_pendings['total_price'];
         }
         ?>
         <h3><span>PKR </span><?= $total_pendings; ?></h3>
         <p>total pendings</p>
         <a href="placed_orders.php" class="btn">see orders</a>
      </div>

      <div class="box">
         <?php
         $total_completes = 0;
         $select_completes = $conn->prepare("SELECT total_price FROM `orders` WHERE payment_status = ?");
         $select_completes->execute(['completed']);
         while($fetch_completes = $select_completes->fetch(PDO::FETCH_ASSOC)){
            $total_completes += $fetch_completes['total_price'];
         }
         ?>
         <h3><span>PKR </span><?= $total_completes; ?></h3>
         <p>total completes</p>
         <a href="placed_orders.php" class="btn">see orders</a>
      </div>

      <div class="box">
         <?php
         $select_orders = $conn->prepare("SELECT COUNT(*) as count FROM `orders`");
         $select_orders->execute();
         $numbers_of_orders = $select_orders->fetch(PDO::FETCH_ASSOC)['count'];
         ?>
         <h3><?= $numbers_of_orders; ?></h3>
         <p>total orders</p>
         <a href="placed_orders.php" class="btn">see orders</a>
      </div>

      <div class="box">
         <?php
         $select_products = $conn->prepare("SELECT COUNT(*) as count FROM `products`");
         $select_products->execute();
         $numbers_of_products = $select_products->fetch(PDO::FETCH_ASSOC)['count'];
         ?>
         <h3><?= $numbers_of_products; ?></h3>
         <p>products added</p>
         <a href="products.php" class="btn">see products</a>
      </div>

      <div class="box">
         <?php
         $select_users = $conn->prepare("SELECT COUNT(*) as count FROM `users`");
         $select_users->execute();
         $numbers_of_users = $select_users->fetch(PDO::FETCH_ASSOC)['count'];
         ?>
         <h3><?= $numbers_of_users; ?></h3>
         <p>users accounts</p>
         <a href="users_accounts.php" class="btn">see users</a>
      </div>

      <div class="box">
         <?php
         $select_admins = $conn->prepare("SELECT COUNT(*) as count FROM `admin`");
         $select_admins->execute();
         $numbers_of_admins = $select_admins->fetch(PDO::FETCH_ASSOC)['count'];
         ?>
         <h3><?= $numbers_of_admins; ?></h3>
         <p>admins</p>
         <a href="admin_accounts.php" class="btn">see admins</a>
      </div>

      <div class="box">
         <?php
         $select_messages = $conn->prepare("SELECT COUNT(*) as count FROM `messages`");
         $select_messages->execute();
         $numbers_of_messages = $select_messages->fetch(PDO::FETCH_ASSOC)['count'];
         ?>
         <h3><?= $numbers_of_messages; ?></h3>
         <p>new messages</p>
         <a href="messages.php" class="btn">see messages</a>
      </div>
   </div>
</section>

<script src="../js/admin_script.js"></script>
</body>
</html>
